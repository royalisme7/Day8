﻿Public Class RAM_class

End Class
Public Double TotalGigabytes
Public Brand

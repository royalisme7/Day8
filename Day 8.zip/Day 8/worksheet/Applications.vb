﻿Public Class Applications

End Class

Public String ApplicationName;
Public String Applicationtype;
Public String RequiredRAM;
Public String Requiredstorgae;

}Public ApplictionName

ApplictionName = "Slack";
Applictiontype = "Messaging";
RequiredRam = 4.0;
Requirestoreage = 0.512;

Public void Motherboard.Add.ApplicationsInHardDrive; 
   // Adding appliction
  If RAM_class; <RequiredRAM; > RequiredStorage; Add.run;


{
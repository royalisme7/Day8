﻿Public Class Computer

End Class

﻿{
Public Class Motherboard_class

End Class
Public String Manufacturer;
Public CPU Processor;
Public RAM TemporaryMemory;
Public HardDrive Storage;
Public GPU Graphics;

Public String Motherboard(Manufacturer Manufacturer, RAM ram, CPU cpu, Harddrive harddive, GPU gpu)
  Manufacturer = manufacturer;
    TemporaryMemory = ram;
    Processor = cpu;
    Storage = HardDrive;
    Graphics = GPU;

Public Void InstallApplication (Motherboard Motherboard)
    {

}
}